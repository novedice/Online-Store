// export const CATEGORIES = [
//   'smartphones',
//   'laptops',
//   'fragrances',
//   'skincare',
//   'groceries',
//   'home-decoration', 
//   'furniture', 
//   'tops'
// ];
export const CATEGORIES = ['smartphones', 
'laptops', 'fraqrances', 'skincare', 'groceries', 'home-decoration', 'furniture', 'tops', 'womens-dresses', 'womens-shoes', 'mens-shirts', 'mens-shoes', 'mens-watches', 'womens-watches', 'womens-bags', 'womens-jewellery', 'sunglasses', 'automotive', 'motorcycle', 'lighting']


export const BRANDS = [
  'apple',
  'samsung',
  'huawei',
  'oppo',
  'microsoft surface',
  'infinix',
  'hp pavilion',
  'impression of acqua di gio',
  'royal_mirage',
  'fog scent xpressio',
  'al munakh',
  "l'oreal paris"
];


