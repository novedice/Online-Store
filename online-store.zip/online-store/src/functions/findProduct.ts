import { allProducts } from '../hooks/products';
import { IProduct } from '../types/types';

export function findProd(id: string | undefined): IProduct | undefined {
  if (id) {
    return allProducts.find((product) => product.id === +id)
  }
}
